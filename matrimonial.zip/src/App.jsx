import React from "react";
import Navbar from "./component/Navbar";
import Login from "./component/Login";
import Home from "./component/home/Home";
import Register from "./component/Register";
import { Route, Routes } from "react-router-dom";

const App = () => {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  );
};

export default App;