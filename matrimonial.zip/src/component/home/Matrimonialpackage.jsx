import React from "react";
import { FaCheckCircle } from "react-icons/fa";

const Matrimonialpackage = () => {
  const packages = [
    {
      name: "Free",
      price: "0",
      duration: 30,
      contactViews: 20,
      interestExpress: 50,
      imageUploads: 20,
      featured: false,
    },
    {
      name: "One Day",
      price: "10",
      duration: 1,
      contactViews: 10,
      interestExpress: 10,
      imageUploads: 10,
      featured: false,
    },
    {
      name: "Gold",
      price: "50",
      duration: 30,
      contactViews: "100",
      interestExpress: "100",
      imageUploads: "50",
      featured: true,
    },
    {
      name: "Diamond",
      price: "100",
      duration: 30,
      contactViews: "150",
      interestExpress: "150",
      imageUploads: "10",
      featured: false,
    },
  ];

  return (
    <div className="py-10 mb-20 bg-gray-100">
      <div className="container mx-auto px-6 text-center">
        <h3 className="text-4xl font-bold text-gray-800 mb-4">
          Matrimonial Package
        </h3>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-16">
          Every user have their own package. Anyone can upgrade package or buy
          package through online payment system.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-center">
          {packages.map((pkg, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-xl shadow-lg p-8 transition-transform duration-300 ${
                pkg.featured
                  ? "transform lg:scale-110 border-4 border-pink-500 z-10"
                  : "border border-gray-200"
              }`}
            >
              {pkg.featured && (
                <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2">
                  <span className="px-4 py-1 text-sm font-semibold text-white bg-pink-500 rounded-full">
                    Most Popular
                  </span>
                </div>
              )}
              <h4 className="text-2xl font-bold text-gray-800 mb-2">{pkg.name}</h4>
              <div className="text-5xl font-extrabold text-gray-900 mb-4">
                <span className="text-3xl align-top">₹</span>
                {pkg.price}
              </div>

              <ul className="space-y-4 text-left text-gray-600 mb-8">
                <li className="flex items-center gap-3"><FaCheckCircle className="text-green-500" /><span>Duration ({pkg.duration} Days)</span></li>
                <li className="flex items-center gap-3"><FaCheckCircle className="text-green-500" /><span>Contact View ({pkg.contactViews})</span></li>
                <li className="flex items-center gap-3"><FaCheckCircle className="text-green-500" /><span>Interest Express ({pkg.interestExpress})</span></li>
                <li className="flex items-center gap-3"><FaCheckCircle className="text-green-500" /><span>Image Upload ({pkg.imageUploads})</span></li>
              </ul>

              <button className="w-full py-3 text-lg font-semibold rounded-lg transition-all bg-pink-500 text-white shadow-lg hover:bg-pink-600 ">
                Buy Now
              </button>
            </div>
          ))}
        </div>
        <div className="mt-16">
          <button className="px-8 py-3 font-semibold text-pink-600 transition bg-white border-2 border-pink-500 rounded-full shadow-md transform hover:scale-105 hover:bg-pink-500 hover:text-white">
            See More
          </button>
        </div>
      </div>
    </div>
  );
};

export default Matrimonialpackage;